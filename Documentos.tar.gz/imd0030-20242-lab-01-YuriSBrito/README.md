[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/OBS1bAIz)
[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=16435836)
# Lab #01 - Preparando o ambiente

Neste laboratório iremos conhecer e configurar o ambiente de programação que vamos utilizar durante o nosso curso. A proposta é usarmos um ambiente de programação e desenvolvimento em nuvem com o auxílio das ferramentas e serviços oferecidos pelo GitHub. Além da função de repositório git, iremos utilizar o GitHub Classroom e o GitHub Codespaces.

### GitHub

Visão geral do [GitHub](https://docs.github.com/pt/get-started/start-your-journey/about-github-and-git).

### GitHub Classrooom

Visão geral do [GitHub Classroom](https://docs.github.com/pt/education/manage-coursework-with-github-classroom/get-started-with-github-classroom/about-github-classroom).

### GitHub Codespaces

Visão geral do [GitHub Codespaces](https://docs.github.com/pt/codespaces/overview).

## Atividade 1.1. Nosso primeiro programa em C++

Desenvolva um simples programa *Hello World* em C++ em um arquivo chamado `helloworld.cpp`. Um Hello World é um programa que simplesmente imprime na saída padrão a frase "Hello world!". O Código a seguir pode ser utilizado caso queira:

```c++
#include <iostream>

int main() {   
   std::cout << "Hello world!" << std::endl;   
   return 0;
}
```

Exemplo da execução do programa:

```bash
$ ./helloworld
Hello world!
```


## Atividade 1.2. Manipulando entrada e saída com C++

Para fixarmos as diferenças entre C e C++ ao se manipular entrada e saída, desenvolva um programa (em um arquivo chamado `media.cpp`) que calcula a média aritmética de 3 números inteiros fornecidos pelo usuário através da entrada padrão. A saída do programa deve ser somente a nota referente a média aritmética das 3 notas fornecidas pelo usuário. Exemplo de interação com o programa:

```bash
$ ./media
Entre com a nota da unidade 1: 7
Entre com a nota da unidade 2: 6
Entre com a nota da unidade 3: 9
Média: 7.33
```

## Compilação de um programa desenvolvido em C++

Utilize as *option flags* `-Wall`,  `-std=c++17` e `-o` no momento da compilação. Exemplo:

```bash
$ g++ -Wall -std=c++17 -o helloworld helloworld.cpp
```

## Objetivos do laboratório

Nossa ideia é se familiarizar com o fluxo de desenvolvimento no ambiente configurado. Os objetivos a serem atingidos:

- [ ] Aceitar a atividade através do GitHub Classroom e associar sua conta ao nome incluído na turma;
- [ ] Abrir o repositório no GitHub Codespaces (ou no ambiente desejado);
- [ ] Codificar o(s) programa(s) requisitado(s);
- [ ] Compilar o código usando o compilador g++ dentro do ambiente de nuvem (ou no ambiente desejado);
- [ ] Executar o código dentro do ambiente de nuvem (ou no ambiente desejado);
- [ ] Realizar o *commit* e o *push* do seu código para a *branch main* do seu repositório privado;
- [ ] Verificar o *pipeline* de correção automática.
