#include <iostream>

int main(){
    double nota1, nota2, nota3;

    std::cout << "Entre com a nota da unidade 1: ";
    std::cin >> nota1;
    std::cout << "Entre com a nota da unidade 2: ";
    std::cin >> nota2;
    std::cout << "Entre com a nota da unidade 3: ";
    std::cin >> nota3;

    std::cout << "Média: " << (nota1 + nota2 + nota3)/3 << std::endl;

    return 0;
}