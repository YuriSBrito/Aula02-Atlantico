#include <iostream>

int readNumber();
void writeAnswer(int soma);

int main(){
    int soma = 0;

    for(int i = 0; i < 2; i++){
        soma += readNumber();
    }

    writeAnswer(soma);

    return 0;
}

int readNumber(){
    int num;
    std::cout << "Digite um número inteiro: ";
    std::cin >> num;
    return num;
}

void writeAnswer(int soma){
    std::cout << "Soma: " << soma << std::endl;
}