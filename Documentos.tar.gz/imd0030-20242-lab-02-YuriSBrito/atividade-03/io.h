#ifndef IO_H
#define IO_H

int readNumber();
void writeAnswer(int soma);

#endif