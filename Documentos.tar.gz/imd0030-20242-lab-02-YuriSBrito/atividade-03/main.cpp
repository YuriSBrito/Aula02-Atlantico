#include <iostream>
#include "io.h"

int main(){
    int soma = 0;

    for(int i = 0; i < 2; i++){
        soma += readNumber();
    }

    writeAnswer(soma);

    return 0;
}
