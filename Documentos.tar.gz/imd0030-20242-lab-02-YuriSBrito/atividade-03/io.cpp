#include <iostream>
#include "io.h"

int readNumber(){
    int num;
    std::cout << "Digite um número inteiro: ";
    std::cin >> num;
    return num;
}

void writeAnswer(int soma){
    std::cout << "Soma: " << soma << std::endl;
}
