import os

def check_04_files():
    assert os.path.exists('./atividade-03/main.o') is True
    assert os.path.exists('./atividade-03/io.o') is True
    assert os.path.exists('./atividade-03/main') is True
    assert os.path.exists('./atividade-03/Makefile') is True

check_04_files()