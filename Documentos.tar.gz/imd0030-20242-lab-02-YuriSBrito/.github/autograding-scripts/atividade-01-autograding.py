FCN_DECLARATIONS = ["main(", "void writeAnswer(", "int readNumber("]

def test_01_fcn_declarations():
    fhand = open('./atividade-01/main.cpp')
    source_code = fhand.read()
    for fcn_declaration in FCN_DECLARATIONS:
        assert fcn_declaration.lower() in source_code.lower()

