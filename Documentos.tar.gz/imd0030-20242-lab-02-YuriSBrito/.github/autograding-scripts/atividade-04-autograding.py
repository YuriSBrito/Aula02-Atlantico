MAKEFILES_ACTIONS = ["main", "main.o", "io.o", "test", "clean"]

def test_04_make_actions():
    fhand = open('./atividade-03/Makefile')
    source_code = fhand.read()
    for action in MAKEFILES_ACTIONS:
        assert action.lower() in source_code.lower()