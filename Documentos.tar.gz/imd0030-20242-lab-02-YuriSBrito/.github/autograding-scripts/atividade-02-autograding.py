FCN_DECLARATIONS_MAIN_CPP = ["main("]
FCN_DECLARATIONS_IO_CPP = ["void writeAnswer(", "int readNumber("]

def test_02_fcn_declarations_main_cpp():
    fhand = open('./atividade-02/main.cpp')
    source_code = fhand.read()
    for fcn_declaration in FCN_DECLARATIONS_MAIN_CPP:
        assert fcn_declaration.lower() in source_code.lower()

def test_02_fcn_declarations_io_cpp():
    fhand = open('./atividade-02/io.cpp')
    source_code = fhand.read()
    for fcn_declaration in FCN_DECLARATIONS_IO_CPP:
        assert fcn_declaration.lower() in source_code.lower()