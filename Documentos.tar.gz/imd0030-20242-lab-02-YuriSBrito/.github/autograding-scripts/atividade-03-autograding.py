FCN_DECLARATIONS_MAIN_CPP = ["main(", "io.h"]
FCN_DECLARATIONS_IO_CPP = ["void writeAnswer(", "int readNumber(", "io.h"]
FCN_DECLARATIONS_IO_H = ["void writeAnswer(", "int readNumber(", "#define", "#ifndef", "endif"]

def test_03_fcn_declarations_main_cpp():
    fhand = open('./atividade-03/main.cpp')
    source_code = fhand.read()
    for fcn_declaration in FCN_DECLARATIONS_MAIN_CPP:
        assert fcn_declaration.lower() in source_code.lower()

def test_03_fcn_declarations_io_cpp():
    fhand = open('./atividade-03/io.cpp')
    source_code = fhand.read()
    for fcn_declaration in FCN_DECLARATIONS_IO_CPP:
        assert fcn_declaration.lower() in source_code.lower()

def test_03_fcn_declarations_io_h():
    fhand = open('./atividade-03/io.h')
    source_code = fhand.read()
    for fcn_declaration in FCN_DECLARATIONS_IO_H:
        assert fcn_declaration.lower() in source_code.lower()


